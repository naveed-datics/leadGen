"use client";

import { useEffect, useState } from "react";
import type { ProposalSummary } from "@/lib/types";

type ModalMode = "create" | "edit" | "view";

interface ProposalModalProps {
  open: boolean;
  mode: ModalMode;
  businessName: string;
  initialBody: string;
  proposal: ProposalSummary | null;
  saving: boolean;
  onClose: () => void;
  onSave: (body: string) => Promise<void>;
  onMarkSent: (body: string) => Promise<void>;
}

export function ProposalModal({
  open,
  mode,
  businessName,
  initialBody,
  proposal,
  saving,
  onClose,
  onSave,
  onMarkSent,
}: ProposalModalProps) {
  const [body, setBody] = useState(initialBody);
  const readOnly = mode === "view";

  useEffect(() => {
    if (open) {
      setBody(proposal?.body ?? initialBody);
    }
  }, [open, proposal, initialBody]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="proposal-title"
    >
      <button
        type="button"
        className="absolute inset-0 bg-black/50"
        onClick={onClose}
        aria-label="Close"
      />
      <div className="relative z-10 w-full max-w-lg rounded-2xl border border-zinc-200 bg-white p-6 shadow-xl dark:border-zinc-700 dark:bg-zinc-900">
        <h2
          id="proposal-title"
          className="text-lg font-semibold text-zinc-900 dark:text-zinc-50"
        >
          {readOnly ? "Proposal" : mode === "create" ? "Create proposal" : "Edit proposal"}
        </h2>
        <p className="mt-1 text-sm text-zinc-500">{businessName}</p>

        {readOnly && proposal?.sentAt && (
          <p className="mt-2 text-xs text-emerald-600 dark:text-emerald-400">
            Sent{" "}
            {new Date(proposal.sentAt).toLocaleString("en-US", {
              dateStyle: "medium",
              timeStyle: "short",
            })}
          </p>
        )}

        <textarea
          value={body}
          onChange={(e) => setBody(e.target.value)}
          readOnly={readOnly}
          rows={12}
          className="mt-4 w-full resize-y rounded-lg border border-zinc-300 bg-white px-3 py-2 text-sm text-zinc-900 focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 read-only:bg-zinc-50 dark:border-zinc-700 dark:bg-zinc-950 dark:text-zinc-100 dark:read-only:bg-zinc-900"
        />

        <div className="mt-5 flex flex-wrap justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg border border-zinc-300 px-4 py-2 text-sm font-medium text-zinc-700 hover:bg-zinc-50 dark:border-zinc-600 dark:text-zinc-300"
          >
            Close
          </button>
          {!readOnly && (
            <>
              <button
                type="button"
                disabled={saving || !body.trim()}
                onClick={() => onSave(body)}
                className="rounded-lg bg-zinc-800 px-4 py-2 text-sm font-medium text-white hover:bg-zinc-900 disabled:opacity-60 dark:bg-zinc-100 dark:text-zinc-900"
              >
                {saving ? "Saving…" : "Save draft"}
              </button>
              <button
                type="button"
                disabled={saving || !body.trim()}
                onClick={() => onMarkSent(body)}
                className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-700 disabled:opacity-60"
              >
                {saving ? "Sending…" : "Mark as sent"}
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
