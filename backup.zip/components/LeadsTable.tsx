"use client";

import { PhoneCell } from "@/components/PhoneCell";
import type { LeadWithProposal, SearchDetail } from "@/lib/types";

interface LeadsTableProps {
  search: SearchDetail;
  leads: LeadWithProposal[];
  checkingWhatsapp?: boolean;
  onCreateProposal: (lead: LeadWithProposal) => void;
  onEditProposal: (lead: LeadWithProposal) => void;
  onViewProposal: (lead: LeadWithProposal) => void;
}

export function LeadsTable({
  search,
  leads,
  checkingWhatsapp = false,
  onCreateProposal,
  onEditProposal,
  onViewProposal,
}: LeadsTableProps) {
  if (leads.length === 0) {
    return (
      <p className="text-sm text-zinc-600 dark:text-zinc-400">
        No leads without a website were found for this search.
      </p>
    );
  }

  return (
    <section className="space-y-4">
      <p className="text-sm text-zinc-600 dark:text-zinc-400">
        {search.totalWithoutWebsite} leads without a website · scanned{" "}
        {search.totalFetched} businesses
      </p>
      <div className="overflow-hidden rounded-2xl border border-zinc-200 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900">
        <div className="hidden overflow-x-auto sm:block">
          <table className="min-w-full divide-y divide-zinc-200 dark:divide-zinc-800">
            <thead className="bg-zinc-50 dark:bg-zinc-950/50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-zinc-500">
                  Business
                </th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-zinc-500">
                  Phone
                </th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-zinc-500">
                  Rating
                </th>
                <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wide text-zinc-500">
                  Proposal
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800">
              {leads.map((lead) => (
                <tr
                  key={lead.id}
                  className="hover:bg-zinc-50/80 dark:hover:bg-zinc-800/30"
                >
                  <td className="px-4 py-3">
                    <p className="font-medium text-zinc-900 dark:text-zinc-100">
                      {lead.title}
                    </p>
                    <p className="text-xs text-zinc-500">{lead.address ?? "—"}</p>
                  </td>
                  <td className="px-4 py-3 text-sm text-zinc-600 dark:text-zinc-400">
                    <PhoneCell
                      phone={lead.phone}
                      hasWhatsapp={lead.hasWhatsapp}
                      checking={
                        checkingWhatsapp && lead.phone != null && lead.hasWhatsapp === null
                      }
                    />
                  </td>
                  <td className="px-4 py-3 text-sm text-zinc-600 dark:text-zinc-400">
                    {formatRating(lead)}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <ProposalAction
                      lead={lead}
                      onCreate={onCreateProposal}
                      onEdit={onEditProposal}
                      onView={onViewProposal}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <ul className="divide-y divide-zinc-100 sm:hidden dark:divide-zinc-800">
          {leads.map((lead) => (
            <li key={lead.id} className="space-y-2 px-4 py-4">
              <p className="font-medium">{lead.title}</p>
              <PhoneCell
                phone={lead.phone}
                hasWhatsapp={lead.hasWhatsapp}
                checking={
                  checkingWhatsapp && lead.phone != null && lead.hasWhatsapp === null
                }
              />
              <ProposalAction
                lead={lead}
                onCreate={onCreateProposal}
                onEdit={onEditProposal}
                onView={onViewProposal}
              />
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

function ProposalAction({
  lead,
  onCreate,
  onEdit,
  onView,
}: {
  lead: LeadWithProposal;
  onCreate: (lead: LeadWithProposal) => void;
  onEdit: (lead: LeadWithProposal) => void;
  onView: (lead: LeadWithProposal) => void;
}) {
  if (!lead.proposal) {
    return (
      <button
        type="button"
        onClick={() => onCreate(lead)}
        className="inline-flex items-center gap-1 rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-emerald-700"
        title="Create proposal"
      >
        <PlusIcon />
        Create
      </button>
    );
  }

  if (lead.proposal.status === "sent") {
    return (
      <button
        type="button"
        onClick={() => onView(lead)}
        className="inline-flex items-center gap-1 rounded-lg border border-zinc-300 px-3 py-1.5 text-xs font-medium text-zinc-700 hover:bg-zinc-50 dark:border-zinc-600 dark:text-zinc-300"
        title="View proposal"
      >
        <EyeIcon />
        View
      </button>
    );
  }

  return (
    <div className="flex justify-end gap-2">
      <button
        type="button"
        onClick={() => onEdit(lead)}
        className="rounded-lg border border-zinc-300 px-3 py-1.5 text-xs font-medium text-zinc-700 hover:bg-zinc-50 dark:border-zinc-600 dark:text-zinc-300"
      >
        Edit
      </button>
    </div>
  );
}

function formatRating(lead: LeadWithProposal): string {
  if (lead.rating == null) return "—";
  const reviews =
    lead.reviews != null ? ` (${lead.reviews})` : "";
  return `${lead.rating}★${reviews}`;
}

function PlusIcon() {
  return (
    <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden>
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
    </svg>
  );
}

function EyeIcon() {
  return (
    <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden>
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
    </svg>
  );
}
