"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { LeadsTable } from "@/components/LeadsTable";
import { ProposalModal } from "@/components/ProposalModal";
import { buildProposalTemplate } from "@/lib/proposal-template";
import type { LeadWithProposal, ProposalSummary, SearchDetail } from "@/lib/types";

type ModalMode = "create" | "edit" | "view";

export default function SearchDetailPage() {
  const params = useParams();
  const id = params.id as string;

  const [search, setSearch] = useState<SearchDetail | null>(null);
  const [leads, setLeads] = useState<LeadWithProposal[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [modalOpen, setModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<ModalMode>("create");
  const [activeLead, setActiveLead] = useState<LeadWithProposal | null>(null);
  const [saving, setSaving] = useState(false);
  const [checkingWhatsapp, setCheckingWhatsapp] = useState(false);
  const whatsappCheckStarted = useRef(false);

  const loadSearch = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/searches/${id}`);
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Failed to load search");
        return;
      }
      setSearch(data.search);
      setLeads(data.leads);
    } catch {
      setError("Network error");
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    whatsappCheckStarted.current = false;
    loadSearch();
  }, [loadSearch]);

  const checkWhatsapp = useCallback(async (searchId: string) => {
    setCheckingWhatsapp(true);
    try {
      const res = await fetch("/api/whatsapp/check", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ searchId }),
      });
      const data = await res.json();
      if (!res.ok) return;

      const results = data.results as Record<string, boolean>;
      setLeads((prev) =>
        prev.map((lead) =>
          results[lead.id] !== undefined
            ? { ...lead, hasWhatsapp: results[lead.id] }
            : lead,
        ),
      );
    } finally {
      setCheckingWhatsapp(false);
    }
  }, []);

  useEffect(() => {
    if (!search || leads.length === 0 || whatsappCheckStarted.current) return;

    const needsCheck = leads.some(
      (lead) => lead.phone && lead.hasWhatsapp === null,
    );
    if (!needsCheck) return;

    whatsappCheckStarted.current = true;
    checkWhatsapp(search.id);
  }, [search, leads, checkWhatsapp]);

  function openCreate(lead: LeadWithProposal) {
    setActiveLead(lead);
    setModalMode("create");
    setModalOpen(true);
  }

  function openEdit(lead: LeadWithProposal) {
    setActiveLead(lead);
    setModalMode("edit");
    setModalOpen(true);
  }

  function openView(lead: LeadWithProposal) {
    setActiveLead(lead);
    setModalMode("view");
    setModalOpen(true);
  }

  function getInitialBody(): string {
    if (!activeLead || !search) return "";
    if (activeLead.proposal?.body) return activeLead.proposal.body;
    return buildProposalTemplate({
      businessName: activeLead.title,
      industry: search.industry,
      location: search.location,
    });
  }

  function updateLeadProposal(leadId: string, proposal: ProposalSummary) {
    setLeads((prev) =>
      prev.map((l) => (l.id === leadId ? { ...l, proposal } : l)),
    );
  }

  async function handleSave(body: string) {
    if (!activeLead) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/leads/${activeLead.id}/proposal`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ body }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Save failed");
      updateLeadProposal(activeLead.id, data.proposal);
      setActiveLead((l) => (l ? { ...l, proposal: data.proposal } : l));
    } catch (e) {
      alert(e instanceof Error ? e.message : "Save failed");
    } finally {
      setSaving(false);
    }
  }

  async function handleMarkSent(body: string) {
    if (!activeLead) return;
    setSaving(true);
    try {
      await handleSave(body);
      const res = await fetch(`/api/leads/${activeLead.id}/proposal`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "sent" }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Failed to mark sent");
      updateLeadProposal(activeLead.id, data.proposal);
      setModalMode("view");
      setActiveLead((l) => (l ? { ...l, proposal: data.proposal } : l));
    } catch (e) {
      alert(e instanceof Error ? e.message : "Failed to mark sent");
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <main className="mx-auto max-w-5xl px-4 py-10 sm:px-6">
        <p className="text-sm text-zinc-500">Loading…</p>
      </main>
    );
  }

  if (error || !search) {
    return (
      <main className="mx-auto max-w-5xl px-4 py-10 sm:px-6">
        <p className="text-sm text-red-600">{error ?? "Not found"}</p>
        <Link href="/searches" className="mt-4 inline-block text-sm text-emerald-600">
          Back to history
        </Link>
      </main>
    );
  }

  return (
    <main className="mx-auto flex w-full max-w-5xl flex-1 flex-col gap-6 px-4 py-10 sm:px-6 sm:py-14">
      <header className="space-y-2">
        <Link
          href="/searches"
          className="text-sm text-emerald-600 hover:text-emerald-700 dark:text-emerald-400"
        >
          ← Back to history
        </Link>
        <h1 className="text-2xl font-bold text-zinc-900 dark:text-zinc-50">
          {search.query}
        </h1>
        <p className="text-sm text-zinc-500">
          {new Date(search.createdAt).toLocaleString("en-US", {
            dateStyle: "medium",
            timeStyle: "short",
          })}
        </p>
        {checkingWhatsapp && (
          <p className="text-xs text-zinc-500">Checking WhatsApp numbers…</p>
        )}
      </header>

      <LeadsTable
        search={search}
        leads={leads}
        checkingWhatsapp={checkingWhatsapp}
        onCreateProposal={openCreate}
        onEditProposal={openEdit}
        onViewProposal={openView}
      />

      {activeLead && (
        <ProposalModal
          open={modalOpen}
          mode={modalMode}
          businessName={activeLead.title}
          initialBody={getInitialBody()}
          proposal={activeLead.proposal}
          saving={saving}
          onClose={() => setModalOpen(false)}
          onSave={handleSave}
          onMarkSent={handleMarkSent}
        />
      )}
    </main>
  );
}
