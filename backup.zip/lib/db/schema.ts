import { relations } from "drizzle-orm";
import {
  boolean,
  integer,
  pgTable,
  real,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";

export const searches = pgTable("searches", {
  id: uuid("id").defaultRandom().primaryKey(),
  industry: text("industry").notNull(),
  location: text("location").notNull(),
  query: text("query").notNull(),
  totalFetched: integer("total_fetched").notNull(),
  totalWithoutWebsite: integer("total_without_website").notNull(),
  pagesFetched: integer("pages_fetched").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const leads = pgTable("leads", {
  id: uuid("id").defaultRandom().primaryKey(),
  searchId: uuid("search_id")
    .notNull()
    .references(() => searches.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  placeId: text("place_id"),
  address: text("address"),
  phone: text("phone"),
  rating: real("rating"),
  reviews: integer("reviews"),
  type: text("type"),
  mapsUrl: text("maps_url"),
  thumbnail: text("thumbnail"),
  hasWhatsapp: boolean("has_whatsapp"),
  whatsappCheckedAt: timestamp("whatsapp_checked_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const proposals = pgTable("proposals", {
  id: uuid("id").defaultRandom().primaryKey(),
  leadId: uuid("lead_id")
    .notNull()
    .unique()
    .references(() => leads.id, { onDelete: "cascade" }),
  body: text("body").notNull(),
  status: text("status").notNull().default("draft"),
  sentAt: timestamp("sent_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const searchesRelations = relations(searches, ({ many }) => ({
  leads: many(leads),
}));

export const leadsRelations = relations(leads, ({ one }) => ({
  search: one(searches, {
    fields: [leads.searchId],
    references: [searches.id],
  }),
  proposal: one(proposals, {
    fields: [leads.id],
    references: [proposals.leadId],
  }),
}));

export const proposalsRelations = relations(proposals, ({ one }) => ({
  lead: one(leads, {
    fields: [proposals.leadId],
    references: [leads.id],
  }),
}));
