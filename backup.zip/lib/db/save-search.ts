import type { BusinessLead, SearchResult } from "@/lib/types";
import { getDb } from "./index";
import { leads, searches } from "./schema";

export async function saveSearch(
  industry: string,
  location: string,
  result: SearchResult,
): Promise<string> {
  const db = getDb();
  const [search] = await db
    .insert(searches)
    .values({
      industry,
      location,
      query: result.query,
      totalFetched: result.totalFetched,
      totalWithoutWebsite: result.totalWithoutWebsite,
      pagesFetched: result.pagesFetched,
    })
    .returning({ id: searches.id });

  if (result.businesses.length > 0) {
    await db.insert(leads).values(
      result.businesses.map((business: BusinessLead) => ({
        searchId: search.id,
        title: business.title,
        placeId: business.placeId,
        address: business.address,
        phone: business.phone,
        rating: business.rating,
        reviews: business.reviews,
        type: business.type,
        mapsUrl: business.mapsUrl,
        thumbnail: business.thumbnail,
      })),
    );
  }

  return search.id;
}
