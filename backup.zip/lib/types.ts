export interface GpsCoordinates {
  latitude: number;
  longitude: number;
}

export interface SerpApiLocalResult {
  position?: number;
  title: string;
  place_id?: string;
  data_id?: string;
  rating?: number;
  reviews?: number;
  type?: string;
  types?: string[];
  address?: string;
  phone?: string;
  website?: string;
  gps_coordinates?: GpsCoordinates;
  thumbnail?: string;
  serpapi_thumbnail?: string;
}

export interface SerpApiMapsResponse {
  local_results?: SerpApiLocalResult[];
  error?: string;
}

export interface BusinessLead {
  title: string;
  placeId: string | null;
  address: string | null;
  phone: string | null;
  rating: number | null;
  reviews: number | null;
  type: string | null;
  mapsUrl: string | null;
  thumbnail: string | null;
}

export interface SearchResult {
  query: string;
  totalFetched: number;
  totalWithoutWebsite: number;
  pagesFetched: number;
  businesses: BusinessLead[];
  searchId?: string;
}

export interface SearchSummary {
  id: string;
  query: string;
  industry: string;
  location: string;
  totalWithoutWebsite: number;
  createdAt: string;
}

export interface ProposalSummary {
  id: string;
  status: "draft" | "sent";
  body: string;
  sentAt: string | null;
}

export interface LeadWithProposal {
  id: string;
  title: string;
  placeId: string | null;
  address: string | null;
  phone: string | null;
  rating: number | null;
  reviews: number | null;
  type: string | null;
  mapsUrl: string | null;
  thumbnail: string | null;
  hasWhatsapp: boolean | null;
  proposal: ProposalSummary | null;
}

export interface SearchDetail {
  id: string;
  query: string;
  industry: string;
  location: string;
  totalFetched: number;
  totalWithoutWebsite: number;
  createdAt: string;
}

export interface SearchRequest {
  industry: string;
  location: string;
}
