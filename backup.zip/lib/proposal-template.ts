interface ProposalTemplateInput {
  businessName: string;
  industry: string;
  location: string;
}

export function buildProposalTemplate({
  businessName,
  industry,
  location,
}: ProposalTemplateInput): string {
  return `Hi ${businessName},

We noticed ${businessName} in ${location} may not have a website yet. We help ${industry} businesses get online with a professional site that brings in more customers.

Would you be open to a quick 10-minute call this week to see if we are a good fit?

Best regards,
Your Name
Your Company`;
}
